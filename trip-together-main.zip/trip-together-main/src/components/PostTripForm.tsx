import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";

interface PostTripFormProps {
  open: boolean;
  onClose: () => void;
  onSubmit: () => void;
}

const PostTripForm = ({ open, onClose, onSubmit }: PostTripFormProps) => {
  const { user } = useAuth();
  const [form, setForm] = useState({
    from_city: "",
    to_city: "",
    trip_date: "",
    trip_time: "",
    seats_needed: 2,
    estimated_cost: 0,
    transport: "car",
    note: "",
  });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.from_city || !form.to_city || !form.trip_date || !form.trip_time) {
      toast.error("Please fill in all required fields");
      return;
    }
    if (!user) { toast.error("Please sign in first"); return; }

    setLoading(true);
    const { error } = await supabase.from("trips").insert({
      user_id: user.id,
      from_city: form.from_city,
      to_city: form.to_city,
      trip_date: form.trip_date,
      trip_time: form.trip_time,
      seats_needed: form.seats_needed,
      estimated_cost: form.estimated_cost,
      transport: form.transport,
      note: form.note || null,
    });
    setLoading(false);

    if (error) { toast.error(error.message); return; }
    toast.success("Trip posted!");
    onSubmit();
    onClose();
    setForm({ from_city: "", to_city: "", trip_date: "", trip_time: "", seats_needed: 2, estimated_cost: 0, transport: "car", note: "" });
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-display text-xl">Post a New Trip</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="mt-2 space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label htmlFor="from">From *</Label>
              <Input id="from" value={form.from_city} onChange={(e) => setForm({ ...form, from_city: e.target.value })} placeholder="Start city" required />
            </div>
            <div>
              <Label htmlFor="to">To *</Label>
              <Input id="to" value={form.to_city} onChange={(e) => setForm({ ...form, to_city: e.target.value })} placeholder="Destination" required />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label htmlFor="date">Date *</Label>
              <Input id="date" type="date" value={form.trip_date} onChange={(e) => setForm({ ...form, trip_date: e.target.value })} required />
            </div>
            <div>
              <Label htmlFor="time">Time *</Label>
              <Input id="time" type="time" value={form.trip_time} onChange={(e) => setForm({ ...form, trip_time: e.target.value })} required />
            </div>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div>
              <Label>Transport *</Label>
              <Select value={form.transport} onValueChange={(v) => setForm({ ...form, transport: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="car">Car</SelectItem>
                  <SelectItem value="bus">Bus</SelectItem>
                  <SelectItem value="train">Train</SelectItem>
                  <SelectItem value="flight">Flight</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="seats">Seats *</Label>
              <Input id="seats" type="number" min={1} max={10} value={form.seats_needed} onChange={(e) => setForm({ ...form, seats_needed: Number(e.target.value) })} required />
            </div>
            <div>
              <Label htmlFor="cost">Cost (₹) *</Label>
              <Input id="cost" type="number" min={0} value={form.estimated_cost} onChange={(e) => setForm({ ...form, estimated_cost: Number(e.target.value) })} required />
            </div>
          </div>
          <div>
            <Label htmlFor="note">Note (optional)</Label>
            <Textarea id="note" value={form.note} onChange={(e) => setForm({ ...form, note: e.target.value })} placeholder="Any details..." rows={2} />
          </div>
          <Button type="submit" className="w-full" disabled={loading}>
            {loading ? "Posting..." : "Post Trip"}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default PostTripForm;
