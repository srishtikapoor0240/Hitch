import { useState, useEffect, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Send, MessageCircle } from "lucide-react";

interface ChatMessage {
  id: string;
  content: string;
  user_id: string;
  created_at: string;
  profile?: { display_name: string };
}

interface TripChatProps {
  tripId: string;
  tripLabel: string;
  open: boolean;
  onClose: () => void;
}

const TripChat = ({ tripId, tripLabel, open, onClose }: TripChatProps) => {
  const { user } = useAuth();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open || !tripId) return;

    const fetchMessages = async () => {
      const { data } = await supabase
        .from("messages")
        .select("*")
        .eq("trip_id", tripId)
        .order("created_at", { ascending: true });

      if (data) {
        // Fetch profiles for messages
        const userIds = [...new Set(data.map((m) => m.user_id))];
        const { data: profiles } = await supabase
          .from("profiles")
          .select("user_id, display_name")
          .in("user_id", userIds);

        const profileMap = new Map(profiles?.map((p) => [p.user_id, p]) || []);
        setMessages(data.map((m) => ({ ...m, profile: profileMap.get(m.user_id) })));
      }
    };

    fetchMessages();

    const channel = supabase
      .channel(`trip-chat-${tripId}`)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "messages", filter: `trip_id=eq.${tripId}` }, async (payload) => {
        const newMsg = payload.new as ChatMessage;
        const { data: profile } = await supabase.from("profiles").select("user_id, display_name").eq("user_id", newMsg.user_id).single();
        setMessages((prev) => [...prev, { ...newMsg, profile: profile || undefined }]);
      })
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [open, tripId]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || !user) return;
    setSending(true);
    await supabase.from("messages").insert({ trip_id: tripId, user_id: user.id, content: input.trim() });
    setInput("");
    setSending(false);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="flex h-[70vh] max-h-[600px] flex-col sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 font-display">
            <MessageCircle className="h-5 w-5 text-primary" />
            Chat — {tripLabel}
          </DialogTitle>
        </DialogHeader>

        <ScrollArea className="flex-1 rounded-md border bg-muted/30 p-3">
          <div className="space-y-3">
            {messages.length === 0 && (
              <p className="py-8 text-center text-sm text-muted-foreground">No messages yet. Say hi! 👋</p>
            )}
            {messages.map((msg) => {
              const isMe = msg.user_id === user?.id;
              return (
                <div key={msg.id} className={`flex ${isMe ? "justify-end" : "justify-start"}`}>
                  <div className={`max-w-[75%] rounded-lg px-3 py-2 text-sm ${isMe ? "bg-primary text-primary-foreground" : "bg-card border"}`}>
                    {!isMe && <p className="mb-0.5 text-xs font-semibold text-muted-foreground">{msg.profile?.display_name || "User"}</p>}
                    <p>{msg.content}</p>
                    <p className={`mt-1 text-[10px] ${isMe ? "text-primary-foreground/60" : "text-muted-foreground"}`}>
                      {new Date(msg.created_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                    </p>
                  </div>
                </div>
              );
            })}
            <div ref={bottomRef} />
          </div>
        </ScrollArea>

        <div className="flex gap-2">
          <Input
            placeholder="Type a message..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && handleSend()}
            disabled={!user}
          />
          <Button size="icon" onClick={handleSend} disabled={sending || !input.trim() || !user}>
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default TripChat;
