import { Calendar, Clock, MapPin, Train, Bus, Car, Plane, Users, IndianRupee, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export interface TripDisplay {
  id: string;
  user_id: string;
  posterName: string;
  from_city: string;
  to_city: string;
  trip_date: string;
  trip_time: string;
  seats_needed: number;
  seats_joined: number;
  estimated_cost: number;
  transport: string;
  note?: string | null;
}

const transportIcons: Record<string, typeof Bus> = {
  bus: Bus,
  train: Train,
  car: Car,
  flight: Plane,
};

const TripCard = ({ trip, onJoin, onChat, isLoggedIn }: { trip: TripDisplay; onJoin: (trip: TripDisplay) => void; onChat: (trip: TripDisplay) => void; isLoggedIn: boolean }) => {
  const TransportIcon = transportIcons[trip.transport] || Car;
  const seatsLeft = trip.seats_needed - trip.seats_joined;
  const perPerson = Math.round(trip.estimated_cost / Math.max(trip.seats_joined + 1, 1));
  const isFull = seatsLeft <= 0;

  return (
    <div className="group relative overflow-hidden rounded-lg border bg-card shadow-card transition-all duration-300 hover:shadow-elevated">
      <div className="h-1.5 bg-gradient-hero" />
      <div className="p-5">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-2">
            <MapPin className="h-4 w-4 shrink-0 text-primary" />
            <div className="font-display">
              <span className="font-semibold text-foreground">{trip.from_city}</span>
              <span className="mx-2 text-muted-foreground">→</span>
              <span className="font-semibold text-foreground">{trip.to_city}</span>
            </div>
          </div>
          <Badge variant="secondary" className="shrink-0 gap-1 capitalize">
            <TransportIcon className="h-3 w-3" />
            {trip.transport}
          </Badge>
        </div>

        <div className="mt-4 flex flex-wrap gap-4 text-sm text-muted-foreground">
          <span className="flex items-center gap-1.5">
            <Calendar className="h-3.5 w-3.5" />
            {new Date(trip.trip_date).toLocaleDateString("en-IN", { day: "numeric", month: "short" })}
          </span>
          <span className="flex items-center gap-1.5">
            <Clock className="h-3.5 w-3.5" />
            {trip.trip_time?.slice(0, 5)}
          </span>
          <span className="flex items-center gap-1.5">
            <Users className="h-3.5 w-3.5" />
            {seatsLeft} seat{seatsLeft !== 1 ? "s" : ""} left
          </span>
        </div>

        {trip.note && <p className="mt-3 text-sm text-muted-foreground italic">"{trip.note}"</p>}

        <div className="mt-4 flex items-center justify-between border-t pt-4">
          <div>
            <p className="text-xs text-muted-foreground">Est. per person</p>
            <p className="flex items-center font-display text-lg font-bold text-foreground">
              <IndianRupee className="h-4 w-4" />{perPerson}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <p className="text-xs text-muted-foreground">by {trip.posterName}</p>
            {isLoggedIn && (
              <Button size="icon" variant="outline" onClick={() => onChat(trip)} className="h-8 w-8">
                <MessageCircle className="h-4 w-4" />
              </Button>
            )}
            <Button size="sm" disabled={isFull || !isLoggedIn} onClick={() => onJoin(trip)}>
              {isFull ? "Full" : isLoggedIn ? "Join" : "Sign in"}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TripCard;
