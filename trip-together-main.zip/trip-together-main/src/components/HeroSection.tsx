import { ArrowRight, Shield, Users, Wallet } from "lucide-react";
import { Button } from "@/components/ui/button";
import heroImage from "@/assets/hero-travel.webp";

const HeroSection = ({ onPostTrip }: { onPostTrip: () => void }) => {
  return (
    <section className="relative overflow-hidden">
      {/* Hero image with overlay */}
      <div className="absolute inset-0">
        <img src={heroImage} alt="Students traveling together" className="h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-r from-foreground/85 via-foreground/70 to-foreground/40" />
      </div>

      <div className="container relative z-10 py-24 md:py-36">
        <div className="max-w-2xl">
          <h1 className="animate-fade-up font-display text-4xl font-bold leading-tight text-primary-foreground md:text-6xl">
            Travel Together,{" "}
            <span className="text-accent">Save Together</span>
          </h1>
          <p className="mt-5 animate-fade-up text-lg text-primary-foreground/80 [animation-delay:150ms] md:text-xl">
            Find college travel companions headed your way. Split costs, stay safe, and make the journey part of the adventure.
          </p>
          <div className="mt-8 flex animate-fade-up flex-wrap gap-4 [animation-delay:300ms]">
            <Button size="lg" onClick={onPostTrip} className="gap-2">
              Post Your Trip <ArrowRight className="h-4 w-4" />
            </Button>
            <Button size="lg" variant="outline" className="border-primary-foreground/30 bg-primary-foreground/10 text-primary-foreground hover:bg-primary-foreground/20" asChild>
              <a href="#trips">Browse Trips</a>
            </Button>
          </div>
        </div>

        {/* Stats */}
        <div className="mt-16 grid animate-fade-up grid-cols-1 gap-4 [animation-delay:450ms] sm:grid-cols-3">
          {[
            { icon: Users, label: "Group Travel", desc: "Find 2-6 companions" },
            { icon: Wallet, label: "Split Costs", desc: "Save up to 60%" },
            { icon: Shield, label: "Stay Safe", desc: "Verified students" },
          ].map((item) => (
            <div key={item.label} className="flex items-center gap-3 rounded-lg border border-primary-foreground/10 bg-primary-foreground/5 p-4 backdrop-blur-sm">
              <item.icon className="h-8 w-8 text-accent" />
              <div>
                <p className="font-display font-semibold text-primary-foreground">{item.label}</p>
                <p className="text-sm text-primary-foreground/60">{item.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
