import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface TripFiltersProps {
  search: string;
  onSearchChange: (v: string) => void;
  transport: string;
  onTransportChange: (v: string) => void;
}

const TripFilters = ({ search, onSearchChange, transport, onTransportChange }: TripFiltersProps) => {
  return (
    <div className="flex flex-col gap-3 sm:flex-row">
      <div className="relative flex-1">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          placeholder="Search by city..."
          value={search}
          onChange={(e) => onSearchChange(e.target.value)}
          className="pl-9"
        />
      </div>
      <Select value={transport} onValueChange={onTransportChange}>
        <SelectTrigger className="w-full sm:w-40">
          <SelectValue placeholder="Transport" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">All Types</SelectItem>
          <SelectItem value="car">Car</SelectItem>
          <SelectItem value="bus">Bus</SelectItem>
          <SelectItem value="train">Train</SelectItem>
          <SelectItem value="flight">Flight</SelectItem>
        </SelectContent>
      </Select>
    </div>
  );
};

export default TripFilters;
