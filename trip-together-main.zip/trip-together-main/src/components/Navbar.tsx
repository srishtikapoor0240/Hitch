import { MapPin, Menu, X, User, LogOut } from "lucide-react";
import { useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";

const Navbar = ({ onPostTrip }: { onPostTrip: () => void }) => {
  const [mobileOpen, setMobileOpen] = useState(false);
  const { user, signOut } = useAuth();

  return (
    <nav className="sticky top-0 z-50 border-b bg-card/80 backdrop-blur-lg">
      <div className="container flex h-16 items-center justify-between">
        <Link to="/" className="flex items-center gap-2 font-display text-xl font-bold text-primary">
          <MapPin className="h-6 w-6" />
          Hitch
        </Link>

        <div className="hidden items-center gap-6 md:flex">
          <a href="/#trips" className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground">
            Browse Trips
          </a>
          <a href="/#how" className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground">
            How It Works
          </a>
          {user ? (
            <>
              <Button onClick={onPostTrip} size="sm">Post a Trip</Button>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="icon" className="h-9 w-9 rounded-full">
                    <User className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem asChild>
                    <Link to="/profile" className="flex items-center gap-2"><User className="h-4 w-4" /> Profile</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={signOut} className="flex items-center gap-2">
                    <LogOut className="h-4 w-4" /> Sign Out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </>
          ) : (
            <Button asChild size="sm"><Link to="/login">Sign In</Link></Button>
          )}
        </div>

        <button className="md:hidden" onClick={() => setMobileOpen(!mobileOpen)}>
          {mobileOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      {mobileOpen && (
        <div className="border-t bg-card p-4 md:hidden">
          <div className="flex flex-col gap-3">
            <a href="/#trips" className="text-sm font-medium text-muted-foreground" onClick={() => setMobileOpen(false)}>Browse Trips</a>
            <a href="/#how" className="text-sm font-medium text-muted-foreground" onClick={() => setMobileOpen(false)}>How It Works</a>
            {user ? (
              <>
                <Button onClick={() => { onPostTrip(); setMobileOpen(false); }} size="sm">Post a Trip</Button>
                <Link to="/profile" className="text-sm font-medium text-muted-foreground" onClick={() => setMobileOpen(false)}>Profile</Link>
                <button className="text-left text-sm font-medium text-muted-foreground" onClick={() => { signOut(); setMobileOpen(false); }}>Sign Out</button>
              </>
            ) : (
              <Button asChild size="sm"><Link to="/login" onClick={() => setMobileOpen(false)}>Sign In</Link></Button>
            )}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
