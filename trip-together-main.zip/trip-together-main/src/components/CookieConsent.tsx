import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Cookie, X } from "lucide-react";

const CookieConsent = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem("cookie-consent");
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1500);
      return () => clearTimeout(timer);
    }
  }, []);

  const accept = () => {
    localStorage.setItem("cookie-consent", "accepted");
    setVisible(false);
  };

  const decline = () => {
    localStorage.setItem("cookie-consent", "declined");
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 p-4 animate-in slide-in-from-bottom-4 duration-500">
      <div className="mx-auto max-w-2xl rounded-xl border border-border bg-card p-4 shadow-elevated sm:p-5">
        <div className="flex items-start gap-3">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/10">
            <Cookie className="h-5 w-5 text-primary" />
          </div>
          <div className="flex-1 space-y-2">
            <p className="font-display text-sm font-semibold text-foreground">We use cookies 🍪</p>
            <p className="text-xs leading-relaxed text-muted-foreground">
              We use cookies to enhance your experience, analyze site traffic, and personalize content. 
              By clicking "Accept", you consent to our use of cookies. You can manage your preferences anytime.
            </p>
            <div className="flex flex-wrap gap-2 pt-1">
              <Button size="sm" onClick={accept} className="h-8 text-xs">Accept All</Button>
              <Button size="sm" variant="outline" onClick={decline} className="h-8 text-xs">Decline</Button>
            </div>
          </div>
          <button onClick={decline} className="text-muted-foreground hover:text-foreground transition-colors">
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieConsent;
