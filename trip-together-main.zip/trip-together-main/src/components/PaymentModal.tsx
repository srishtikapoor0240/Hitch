import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Separator } from "@/components/ui/separator";
import { Checkbox } from "@/components/ui/checkbox";
import { CheckCircle, CreditCard, IndianRupee, Smartphone, Building2, Copy, Check } from "lucide-react";
import { QRCodeSVG } from "qrcode.react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";
import type { TripDisplay } from "@/components/TripCard";

interface PaymentModalProps {
  trip: TripDisplay | null;
  open: boolean;
  onClose: () => void;
}

const PaymentModal = ({ trip, open, onClose }: PaymentModalProps) => {
  const { user } = useAuth();
  const [method, setMethod] = useState("upi");
  const [paid, setPaid] = useState(false);
  const [loading, setLoading] = useState(false);
  const [acceptedTerms, setAcceptedTerms] = useState(false);
  const [copied, setCopied] = useState(false);

  if (!trip) return null;

  const perPerson = Math.round(trip.estimated_cost / (trip.seats_joined + 2));
  const upiId = "hitch@ybl";
  const upiLink = `upi://pay?pa=${upiId}&pn=Hitch&am=${perPerson}&cu=INR&tn=Trip-${trip.id.slice(0, 8)}`;

  const copyUpiId = () => {
    navigator.clipboard.writeText(upiId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePay = async () => {
    if (!user) return;
    if (!acceptedTerms) { toast.error("Please accept the terms & conditions"); return; }
    setLoading(true);

    const { error } = await supabase.from("trip_members").insert({
      trip_id: trip.id,
      user_id: user.id,
      paid: true,
      amount_paid: perPerson,
    });

    if (error) {
      setLoading(false);
      if (error.code === "23505") { toast.error("You already joined this trip"); }
      else { toast.error(error.message); }
      return;
    }

    setLoading(false);
    setPaid(true);
    toast.success("Payment successful! You've joined the trip.");
  };

  const handleClose = () => {
    setPaid(false);
    setMethod("upi");
    setAcceptedTerms(false);
    setCopied(false);
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="font-display text-xl">{paid ? "You're In! 🎉" : "Join & Pay"}</DialogTitle>
        </DialogHeader>

        {paid ? (
          <div className="flex flex-col items-center gap-4 py-6 text-center">
            <CheckCircle className="h-16 w-16 text-success" />
            <div>
              <p className="font-display text-lg font-semibold">Payment Confirmed</p>
              <p className="mt-1 text-sm text-muted-foreground">{trip.from_city} → {trip.to_city} on {new Date(trip.trip_date).toLocaleDateString("en-IN", { day: "numeric", month: "short" })}</p>
              <p className="mt-1 text-sm text-muted-foreground">Contact {trip.posterName} to coordinate details.</p>
            </div>
            <Button onClick={handleClose} className="mt-2 w-full">Done</Button>
          </div>
        ) : (
          <div className="space-y-5">
            {/* Trip summary */}
            <div className="rounded-lg bg-muted p-4">
              <p className="text-sm font-medium text-foreground">{trip.from_city} → {trip.to_city}</p>
              <p className="text-xs text-muted-foreground">{new Date(trip.trip_date).toLocaleDateString("en-IN", { weekday: "short", day: "numeric", month: "short" })} at {trip.trip_time?.slice(0, 5)}</p>
              <Separator className="my-3" />
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Your share</span>
                <span className="flex items-center font-display text-2xl font-bold text-foreground"><IndianRupee className="h-5 w-5" />{perPerson}</span>
              </div>
            </div>

            {/* Payment method */}
            <div>
              <Label className="mb-2 block text-sm font-medium">Payment Method</Label>
              <RadioGroup value={method} onValueChange={setMethod} className="grid grid-cols-3 gap-2">
                {[
                  { value: "upi", label: "UPI", icon: Smartphone },
                  { value: "card", label: "Card", icon: CreditCard },
                  { value: "netbanking", label: "Bank", icon: Building2 },
                ].map((m) => (
                  <Label key={m.value} htmlFor={m.value} className={`flex cursor-pointer flex-col items-center gap-1.5 rounded-lg border-2 p-3 text-center transition-colors ${method === m.value ? "border-primary bg-primary/5" : "border-border hover:border-primary/30"}`}>
                    <RadioGroupItem value={m.value} id={m.value} className="sr-only" />
                    <m.icon className="h-5 w-5" />
                    <span className="text-xs font-medium">{m.label}</span>
                  </Label>
                ))}
              </RadioGroup>
            </div>

            {/* UPI with QR code */}
            {method === "upi" && (
              <div className="space-y-4">
                <div className="flex flex-col items-center gap-3 rounded-lg border border-border bg-card p-4">
                  <p className="text-xs font-medium text-muted-foreground">Scan QR to pay via any UPI app</p>
                  <div className="rounded-lg bg-background p-3">
                    <QRCodeSVG value={upiLink} size={160} level="H" />
                  </div>
                  <div className="flex items-center gap-2 rounded-md bg-muted px-3 py-1.5">
                    <span className="text-sm font-medium text-foreground">{upiId}</span>
                    <button onClick={copyUpiId} className="text-muted-foreground hover:text-foreground transition-colors">
                      {copied ? <Check className="h-4 w-4 text-success" /> : <Copy className="h-4 w-4" />}
                    </button>
                  </div>
                  <p className="text-xs text-muted-foreground">Or pay directly from your UPI app</p>
                  <a href={upiLink} className="inline-flex items-center gap-1.5 rounded-md bg-primary/10 px-4 py-2 text-sm font-medium text-primary hover:bg-primary/20 transition-colors">
                    <Smartphone className="h-4 w-4" /> Open UPI App
                  </a>
                </div>
                <div>
                  <Label htmlFor="upi">UPI ID (optional for verification)</Label>
                  <Input id="upi" placeholder="yourname@upi" />
                </div>
              </div>
            )}

            {method === "card" && (
              <div className="space-y-3">
                <div><Label htmlFor="cardno">Card Number *</Label><Input id="cardno" placeholder="1234 5678 9012 3456" maxLength={19} required /></div>
                <div className="grid grid-cols-2 gap-3">
                  <div><Label htmlFor="expiry">Expiry *</Label><Input id="expiry" placeholder="MM/YY" maxLength={5} required /></div>
                  <div><Label htmlFor="cvv">CVV *</Label><Input id="cvv" placeholder="•••" maxLength={3} type="password" required /></div>
                </div>
              </div>
            )}

            {method === "netbanking" && (
              <div><Label htmlFor="bank">Bank Name *</Label><Input id="bank" placeholder="e.g. State Bank of India" required /></div>
            )}

            {/* Terms & Conditions */}
            <div className="rounded-lg border border-border bg-muted/50 p-3 space-y-2">
              <p className="text-xs font-semibold text-foreground">Terms & Conditions</p>
              <div className="max-h-24 overflow-y-auto text-xs text-muted-foreground space-y-1 pr-1">
                <p>1. By joining this trip, you agree to share the travel costs equally with other passengers.</p>
                <p>2. Cancellations must be made at least 24 hours before the trip date for a full refund.</p>
                <p>3. Hitch is a platform connecting travellers and is not responsible for the conduct of any passenger.</p>
                <p>4. You agree to carry a valid ID during the trip for verification purposes.</p>
                <p>5. Payment amounts are estimated and may vary slightly based on actual expenses.</p>
                <p>6. Personal data is handled per our Privacy Policy. We do not share your information with third parties.</p>
                <p>7. Hitch reserves the right to remove users who violate community guidelines.</p>
              </div>
              <div className="flex items-start gap-2 pt-1">
                <Checkbox id="terms" checked={acceptedTerms} onCheckedChange={(v) => setAcceptedTerms(v === true)} />
                <label htmlFor="terms" className="text-xs text-foreground cursor-pointer leading-tight">
                  I accept the <span className="font-medium text-primary">Terms & Conditions</span> and <span className="font-medium text-primary">Privacy Policy</span>
                </label>
              </div>
            </div>

            <Button onClick={handlePay} className="w-full" disabled={loading || !acceptedTerms}>
              {loading ? "Processing..." : `Pay ₹${perPerson}`}
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default PaymentModal;
