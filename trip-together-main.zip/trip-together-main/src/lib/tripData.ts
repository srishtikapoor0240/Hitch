export interface Trip {
  id: string;
  posterName: string;
  from: string;
  to: string;
  date: string;
  time: string;
  seatsNeeded: number;
  seatsJoined: number;
  estimatedCost: number;
  transport: "bus" | "train" | "car" | "flight";
  note?: string;
}

export const sampleTrips: Trip[] = [
  {
    id: "1",
    posterName: "Aarav Patel",
    from: "Delhi",
    to: "Jaipur",
    date: "2026-03-05",
    time: "06:00",
    seatsNeeded: 3,
    seatsJoined: 1,
    estimatedCost: 450,
    transport: "car",
    note: "Road trip! Will split fuel costs equally.",
  },
  {
    id: "2",
    posterName: "Priya Sharma",
    from: "Mumbai",
    to: "Pune",
    date: "2026-03-08",
    time: "08:30",
    seatsNeeded: 2,
    seatsJoined: 0,
    estimatedCost: 300,
    transport: "bus",
    note: "Taking the expressway bus, DM for details.",
  },
  {
    id: "3",
    posterName: "Rahul Verma",
    from: "Bangalore",
    to: "Mysore",
    date: "2026-03-10",
    time: "07:00",
    seatsNeeded: 4,
    seatsJoined: 2,
    estimatedCost: 250,
    transport: "train",
  },
  {
    id: "4",
    posterName: "Sneha Reddy",
    from: "Chennai",
    to: "Pondicherry",
    date: "2026-03-12",
    time: "09:00",
    seatsNeeded: 2,
    seatsJoined: 1,
    estimatedCost: 350,
    transport: "car",
    note: "Weekend getaway 🏖️",
  },
  {
    id: "5",
    posterName: "Karan Singh",
    from: "Hyderabad",
    to: "Goa",
    date: "2026-03-15",
    time: "22:00",
    seatsNeeded: 5,
    seatsJoined: 3,
    estimatedCost: 1200,
    transport: "flight",
    note: "Spring break trip! Group discount on flights.",
  },
  {
    id: "6",
    posterName: "Ananya Gupta",
    from: "Kolkata",
    to: "Darjeeling",
    date: "2026-03-18",
    time: "05:30",
    seatsNeeded: 3,
    seatsJoined: 0,
    estimatedCost: 600,
    transport: "train",
    note: "Mountain trip, bring warm clothes!",
  },
];
