import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import Navbar from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { MapPin, User, IndianRupee, Navigation, Calendar, Pencil } from "lucide-react";
import { toast } from "sonner";

interface ProfileData {
  display_name: string;
  college: string | null;
  phone: string | null;
  avatar_url: string | null;
}

const Profile = () => {
  const { user } = useAuth();
  const [profile, setProfile] = useState<ProfileData | null>(null);
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({ display_name: "", college: "", phone: "" });
  const [stats, setStats] = useState({ tripsPosted: 0, tripsJoined: 0, totalSaved: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;

    const fetchData = async () => {
      // Fetch profile
      const { data: prof } = await supabase.from("profiles").select("*").eq("user_id", user.id).single();
      if (prof) {
        setProfile(prof);
        setForm({ display_name: prof.display_name, college: prof.college || "", phone: prof.phone || "" });
      }

      // Fetch stats
      const { count: posted } = await supabase.from("trips").select("*", { count: "exact", head: true }).eq("user_id", user.id);
      const { data: memberships } = await supabase.from("trip_members").select("trip_id, amount_paid").eq("user_id", user.id);

      let totalSaved = 0;
      if (memberships && memberships.length > 0) {
        const tripIds = memberships.map((m) => m.trip_id);
        const { data: joinedTrips } = await supabase.from("trips").select("estimated_cost, seats_needed").in("id", tripIds);
        if (joinedTrips) {
          totalSaved = joinedTrips.reduce((sum, t) => sum + Math.round(t.estimated_cost - t.estimated_cost / (t.seats_needed + 1)), 0);
        }
      }

      setStats({ tripsPosted: posted || 0, tripsJoined: memberships?.length || 0, totalSaved });
      setLoading(false);
    };

    fetchData();
  }, [user]);

  const handleSave = async () => {
    if (!user || !form.display_name) { toast.error("Display name is required"); return; }
    const { error } = await supabase.from("profiles").update({
      display_name: form.display_name,
      college: form.college || null,
      phone: form.phone || null,
    }).eq("user_id", user.id);

    if (error) { toast.error(error.message); return; }
    setProfile((prev) => prev ? { ...prev, ...form } : null);
    setEditing(false);
    toast.success("Profile updated!");
  };

  if (!user) {
    return (
      <div className="flex min-h-screen flex-col bg-background">
        <Navbar onPostTrip={() => {}} />
        <div className="flex flex-1 items-center justify-center">
          <div className="text-center">
            <p className="text-lg text-muted-foreground">Please sign in to view your profile.</p>
            <Button asChild className="mt-4"><Link to="/login">Sign In</Link></Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar onPostTrip={() => {}} />
      <div className="container max-w-2xl py-12">
        <h1 className="font-display text-3xl font-bold text-foreground">My Profile</h1>
        <p className="mt-1 text-muted-foreground">{user.email}</p>

        {/* Stats */}
        <div className="mt-8 grid grid-cols-3 gap-4">
          {[
            { icon: Navigation, label: "Trips Posted", value: stats.tripsPosted },
            { icon: Calendar, label: "Trips Joined", value: stats.tripsJoined },
            { icon: IndianRupee, label: "Total Saved", value: `₹${stats.totalSaved}` },
          ].map((s) => (
            <div key={s.label} className="rounded-lg border bg-card p-4 text-center shadow-card">
              <s.icon className="mx-auto h-6 w-6 text-primary" />
              <p className="mt-2 font-display text-2xl font-bold text-foreground">{s.value}</p>
              <p className="text-xs text-muted-foreground">{s.label}</p>
            </div>
          ))}
        </div>

        <Separator className="my-8" />

        {/* Profile Info */}
        <div className="rounded-lg border bg-card p-6 shadow-card">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary text-primary-foreground">
                <User className="h-6 w-6" />
              </div>
              <div>
                <h2 className="font-display text-lg font-semibold text-foreground">{profile?.display_name || "..."}</h2>
                <p className="text-sm text-muted-foreground">{profile?.college || "No college set"}</p>
              </div>
            </div>
            {!editing && (
              <Button variant="outline" size="sm" onClick={() => setEditing(true)} className="gap-1">
                <Pencil className="h-3.5 w-3.5" /> Edit
              </Button>
            )}
          </div>

          {editing && (
            <div className="mt-6 space-y-4">
              <div>
                <Label htmlFor="displayName">Display Name *</Label>
                <Input id="displayName" value={form.display_name} onChange={(e) => setForm({ ...form, display_name: e.target.value })} />
              </div>
              <div>
                <Label htmlFor="college">College</Label>
                <Input id="college" value={form.college} onChange={(e) => setForm({ ...form, college: e.target.value })} placeholder="e.g. IIT Delhi" />
              </div>
              <div>
                <Label htmlFor="phone">Phone</Label>
                <Input id="phone" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="+91 98765 43210" />
              </div>
              <div className="flex gap-2">
                <Button onClick={handleSave}>Save</Button>
                <Button variant="outline" onClick={() => setEditing(false)}>Cancel</Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Profile;
