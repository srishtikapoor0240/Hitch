import { useState, useEffect, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import TripCard from "@/components/TripCard";
import type { TripDisplay } from "@/components/TripCard";
import TripFilters from "@/components/TripFilters";
import PostTripForm from "@/components/PostTripForm";
import PaymentModal from "@/components/PaymentModal";
import TripChat from "@/components/TripChat";
import CookieConsent from "@/components/CookieConsent";
import { Compass, UserPlus, CreditCard } from "lucide-react";

const Index = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [trips, setTrips] = useState<TripDisplay[]>([]);
  const [search, setSearch] = useState("");
  const [transport, setTransport] = useState("all");
  const [postOpen, setPostOpen] = useState(false);
  const [payTrip, setPayTrip] = useState<TripDisplay | null>(null);
  const [chatTrip, setChatTrip] = useState<TripDisplay | null>(null);

  const fetchTrips = async () => {
    const { data: tripsData } = await supabase.from("trips").select("*").order("created_at", { ascending: false });
    if (!tripsData) return;

    // Get member counts
    const { data: members } = await supabase.from("trip_members").select("trip_id");
    const memberCounts = new Map<string, number>();
    members?.forEach((m) => memberCounts.set(m.trip_id, (memberCounts.get(m.trip_id) || 0) + 1));

    // Get poster names
    const userIds = [...new Set(tripsData.map((t) => t.user_id))];
    const { data: profiles } = await supabase.from("profiles").select("user_id, display_name").in("user_id", userIds);
    const nameMap = new Map(profiles?.map((p) => [p.user_id, p.display_name]) || []);

    setTrips(tripsData.map((t) => ({
      id: t.id,
      user_id: t.user_id,
      posterName: nameMap.get(t.user_id) || "Unknown",
      from_city: t.from_city,
      to_city: t.to_city,
      trip_date: t.trip_date,
      trip_time: t.trip_time,
      seats_needed: t.seats_needed,
      seats_joined: memberCounts.get(t.id) || 0,
      estimated_cost: t.estimated_cost,
      transport: t.transport,
      note: t.note,
    })));
  };

  useEffect(() => { fetchTrips(); }, []);

  const filtered = useMemo(() => {
    return trips.filter((t) => {
      const matchesSearch = !search || t.from_city.toLowerCase().includes(search.toLowerCase()) || t.to_city.toLowerCase().includes(search.toLowerCase());
      const matchesTransport = transport === "all" || t.transport === transport;
      return matchesSearch && matchesTransport;
    });
  }, [trips, search, transport]);

  const handleJoin = (trip: TripDisplay) => {
    if (!user) { navigate("/login"); return; }
    setPayTrip(trip);
  };

  const handlePostTrip = () => {
    if (!user) { navigate("/login"); return; }
    setPostOpen(true);
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar onPostTrip={handlePostTrip} />
      <HeroSection onPostTrip={handlePostTrip} />

      {/* How It Works */}
      <section id="how" className="border-b bg-muted/50 py-16">
        <div className="container">
          <h2 className="text-center font-display text-3xl font-bold text-foreground">How It Works</h2>
          <div className="mt-10 grid grid-cols-1 gap-8 md:grid-cols-3">
            {[
              { icon: Compass, title: "Post Your Trip", desc: "Share your travel plan with route, date, and seats available." },
              { icon: UserPlus, title: "Find Companions", desc: "Browse matching trips or let others join yours." },
              { icon: CreditCard, title: "Split & Pay", desc: "Pay your share securely and hit the road together." },
            ].map((step) => (
              <div key={step.title} className="flex flex-col items-center text-center">
                <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-gradient-hero text-primary-foreground">
                  <step.icon className="h-7 w-7" />
                </div>
                <h3 className="mt-4 font-display text-lg font-semibold text-foreground">{step.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Trips */}
      <section id="trips" className="py-16">
        <div className="container">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <h2 className="font-display text-3xl font-bold text-foreground">Available Trips</h2>
              <p className="mt-1 text-muted-foreground">{filtered.length} trip{filtered.length !== 1 ? "s" : ""} found</p>
            </div>
          </div>

          <div className="mt-6">
            <TripFilters search={search} onSearchChange={setSearch} transport={transport} onTransportChange={setTransport} />
          </div>

          <div className="mt-8 grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-3">
            {filtered.map((trip) => (
              <TripCard key={trip.id} trip={trip} onJoin={handleJoin} onChat={(t) => setChatTrip(t)} isLoggedIn={!!user} />
            ))}
          </div>

          {filtered.length === 0 && (
            <div className="py-20 text-center">
              <p className="text-lg text-muted-foreground">No trips match your search. Try a different city or filter.</p>
            </div>
          )}
        </div>
      </section>

      <footer className="border-t bg-card py-8">
        <div className="container flex flex-col items-center gap-2 text-center text-sm text-muted-foreground">
          <p>© 2026 Hitch — Travel together, save together.</p>
          <a href="/terms" className="text-primary hover:underline text-xs">Terms & Conditions</a>
        </div>
      </footer>

      <CookieConsent />

      <PostTripForm open={postOpen} onClose={() => setPostOpen(false)} onSubmit={fetchTrips} />
      <PaymentModal trip={payTrip} open={!!payTrip} onClose={() => { setPayTrip(null); fetchTrips(); }} />
      {chatTrip && (
        <TripChat tripId={chatTrip.id} tripLabel={`${chatTrip.from_city} → ${chatTrip.to_city}`} open={!!chatTrip} onClose={() => setChatTrip(null)} />
      )}
    </div>
  );
};

export default Index;
