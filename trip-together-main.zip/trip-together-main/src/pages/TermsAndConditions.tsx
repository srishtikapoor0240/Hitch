import { Link } from "react-router-dom";
import { MapPin, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";

const sections = [
  { title: "1. Acceptance of Terms", content: "By accessing or using Hitch, you agree to be bound by these Terms and Conditions. If you do not agree with any part of these terms, you must not use the platform." },
  { title: "2. Eligibility", content: "You must be at least 18 years old and a verified college/university student to use this platform. Users must provide accurate personal information during registration." },
  { title: "3. User Accounts", content: "You are responsible for maintaining the confidentiality of your account credentials. You agree to notify us immediately of any unauthorized access. Hitch reserves the right to suspend accounts that violate these terms." },
  { title: "4. Trip Posting & Joining", content: "Trip posters are responsible for the accuracy of trip details including dates, routes, and costs. Joining a trip constitutes an agreement to share costs as indicated. Cancellations must be made at least 24 hours before the trip date." },
  { title: "5. Payments & Refunds", content: "All payments are processed securely through the platform. Cost-sharing amounts are estimates and may vary based on actual expenses. Refunds for cancellations made within 24 hours of the trip are subject to a processing fee." },
  { title: "6. User Conduct", content: "Users must behave respectfully towards fellow travellers. Harassment, discrimination, or any form of misconduct will result in immediate account termination. Users must carry valid identification during trips." },
  { title: "7. Liability Limitation", content: "Hitch is a platform connecting travellers and does not operate as a transport service. We are not liable for any incidents, delays, or damages occurring during trips. Users travel at their own risk." },
  { title: "8. Privacy & Data", content: "We collect and process personal data as described in our Privacy Policy. Your data is not shared with third parties without consent. You may request deletion of your data at any time." },
  { title: "9. Modifications", content: "Hitch reserves the right to modify these terms at any time. Continued use of the platform after changes constitutes acceptance of the updated terms." },
  { title: "10. Contact", content: "For questions about these terms, contact us at support@hitchtravel.in or through the platform's help section." },
];

const TermsAndConditions = () => (
  <div className="min-h-screen bg-background">
    <header className="border-b bg-card">
      <div className="container flex items-center gap-4 py-4">
        <Link to="/">
          <Button variant="ghost" size="icon"><ArrowLeft className="h-5 w-5" /></Button>
        </Link>
        <Link to="/" className="flex items-center gap-2 font-display text-xl font-bold text-primary">
          <MapPin className="h-6 w-6" /> Hitch
        </Link>
      </div>
    </header>

    <main className="container max-w-3xl py-10">
      <h1 className="font-display text-3xl font-bold text-foreground">Terms & Conditions</h1>
      <p className="mt-2 text-sm text-muted-foreground">Last updated: February 25, 2026</p>
      <Separator className="my-6" />

      <div className="space-y-6">
        {sections.map((s) => (
          <div key={s.title}>
            <h2 className="font-display text-lg font-semibold text-foreground">{s.title}</h2>
            <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">{s.content}</p>
          </div>
        ))}
      </div>
    </main>

    <footer className="border-t bg-card py-6">
      <div className="container text-center text-sm text-muted-foreground">
        <p>© 2026 Hitch — Travel together, save together.</p>
      </div>
    </footer>
  </div>
);

export default TermsAndConditions;
